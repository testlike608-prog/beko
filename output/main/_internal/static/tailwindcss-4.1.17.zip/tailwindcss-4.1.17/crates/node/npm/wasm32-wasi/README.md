# `@tailwindcss/oxide-wasm32-wasi`

This is the **wasm32-wasip1-threads** binary for `@tailwindcss/oxide`
